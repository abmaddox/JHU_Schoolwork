/**
 * 
 */
/**
 * 
 */
module maddox_a_hw1 {
}