/**
 * @author Andrew Maddox
 */

module maddox_a_hw3 {
	requires java.desktop;
	requires BhcUtils;
}