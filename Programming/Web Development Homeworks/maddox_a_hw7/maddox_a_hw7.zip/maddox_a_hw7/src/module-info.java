/**
 * @author Andrew Maddox
 * @since Mar 7, 2024
 */
/**
 * 
 */
module maddox_a_hw7 {
	requires BhcUtils;
}